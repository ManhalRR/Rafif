# Commerce Analytics Platform — открыть локально

В архиве находится папка `commerce_platform/` с готовыми агрегатами,
интерактивным интерфейсом, Python/SQL-кодом, тестами и методикой.
Исходные транзакции, CustomerID, XLSX и локальная SQLite-база не включены.

## Посмотреть готовый отчёт

1. Распакуйте ZIP в отдельную папку.
2. Откройте терминал в папке с этим START_HERE.md.
3. Запустите сервер стандартной библиотеки Python:

```sh
python -m http.server 8000 --bind 127.0.0.1 --directory commerce_platform
```

4. Откройте http://127.0.0.1:8000/ в браузере.
5. Для остановки нажмите Ctrl+C в терминале.

Нужен Python 3.10+. Для просмотра не нужны установка библиотек, загрузка
исходного набора или запуск расчётов. Двойной клик по index.html может
блокировать загрузку JSON через fetch, поэтому используйте локальный сервер.

## Воспроизвести расчёты

Для полного пересчёта нужен Python 3.11+ и зависимости из requirements.txt.

```sh
cd commerce_platform
python -m pip install -r requirements.txt
python run.py --tests-only
python forecast.py --tests-only
python run.py
python forecast.py --input results/monthly.csv
python verify_package.py
```

Полный прогон загружает официальный UCI Online Retail II и проверяет SHA-256;
созданные транзакции и SQLite остаются в локальной папке data/.
Детали находятся в commerce_platform/README.md, ENGINE.md, DATA_DICTIONARY.md
и FORECAST.md. Ссылки на остальные проекты и исходный онлайн-архив ведут
на https://manhalrr.github.io/Rafif/ и требуют интернета.

Открытые исторические данные UCI: https://doi.org/10.24432/C5CG6D,
CC BY 4.0. Это аналитический проект на публичных данных. Коммерческий эффект,
прибыль и внедрение в рабочую систему компании не заявляются.
