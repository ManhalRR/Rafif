"""Build a portable Power BI PBIP/PBIR project from verified SQL aggregates.

Run analyze.py first, then python build_powerbi.py.
No absolute local paths or external credentials are stored in the model.
"""
from pathlib import Path
import base64, csv, json, uuid, zipfile

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'powerbi'
MODEL = DEST / 'Retail.SemanticModel'
REPORT = DEST / 'Retail.Report'
SCHEMA = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/'

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def read_csv(name):
    with (ROOT/'results'/name).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))

def table(name, columns, rows, description):
    # A base64 CSV snapshot is a portable Power Query source, not a live connection.
    import io
    s=io.StringIO(newline=''); w=csv.writer(s,lineterminator='\n')
    w.writerow([c[0] for c in columns]); w.writerows(rows)
    payload=base64.b64encode(s.getvalue().encode('utf-8')).decode('ascii')
    types={'string':'type text','int64':'Int64.Type','dateTime':'type date','double':'type number'}
    transforms=', '.join('{"'+c[0]+'", '+types[c[1]]+'}' for c in columns)
    m=['let',f'    Source = Csv.Document(Binary.FromText("{payload}", BinaryEncoding.Base64), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),',
       '    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
       '    Nulls = Table.ReplaceValue(Headers, "", null, Replacer.ReplaceValue, Table.ColumnNames(Headers)),',
       f'    Typed = Table.TransformColumnTypes(Nulls, {{{transforms}}}, "en-US")','in','    Typed']
    cols=[]
    for col,typ,*extra in columns:
        d={'name':col,'dataType':typ,'sourceColumn':col,'summarizeBy':'none'}
        if typ=='dateTime':d.update(formatString='yyyy-MM',annotations=[{'name':'UnderlyingDateTimeDataType','value':'Date'}])
        if extra:d.update(extra[0])
        cols.append(d)
    return {'name':name,'description':description,'columns':cols,
            'partitions':[{'name':name,'mode':'import','source':{'type':'m','expression':m}}]}

sales=read_csv('retail_country_month.csv')
cohorts=read_csv('retail_cohorts.csv')
sales_table=table('Sales', [('MonthIndex','int64',{'isHidden':True}),('Country','string',{'isHidden':True}),('Orders','int64',{'isHidden':True}),('GrossPence','int64',{'isHidden':True}),('CancelledPence','int64',{'isHidden':True}),('NetPence','int64',{'isHidden':True})],
 [[int(r['month'][-2:]),r['country'],r['orders'],r['gross_pence'],r['cancellations_pence'],r['net_pence']] for r in sales],
 'Monthly country aggregates from 01/02 SQL. Grain: country × month. January–November 2011. Money is stored as integer pence.')
months=['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя']
calendar=table('Calendar',[('MonthIndex','int64',{'isHidden':True}),('Month','string',{'sortByColumn':'MonthIndex'}),('MonthDate','dateTime')],
 [[i,f'{months[i-1]} 2011',f'2011-{i:02d}-01'] for i in range(1,12)],'Month dimension. Only complete reporting months; not a daily date table.')
countries=table('Countries',[('Country','string')],[[c] for c in sorted({r['country'] for r in sales})],'Country dimension; sales slicer.')
cohort=table('Cohorts',[('Cohort','string'),('Age','string',{'sortByColumn':'AgeIndex'}),('AgeIndex','int64',{'isHidden':True}),('CohortSize','int64',{'isHidden':True}),('ActiveCustomers','int64',{'isHidden':True})],
 [[r['cohort'],'M'+r['age'],r['age'],r['cohort_size'],int(float(r['active_customers'])) if r['active_customers'] else ''] for r in cohorts],
 'Separate cohort fact table, all countries. First observed positive purchase; December 2010 included as history. Unobserved windows are null, not zero. Country/month sales filters deliberately do not affect this table.')
measures=[
 ('Оборот после отмен','DIVIDE(SUM(Sales[NetPence]), 100)','£#,0.00;−£#,0.00;£0.00','Gross less cancellation value. Not profit or net revenue after all operating expenses.'),
 ('Продажи до отмен','DIVIDE(SUM(Sales[GrossPence]), 100)','£#,0.00','Positive-value sales rows.'),
 ('Сумма отмен','DIVIDE(SUM(Sales[CancelledPence]), 100)','£#,0.00','Absolute value of cancellation rows.'),
 ('Заказы','SUM(Sales[Orders])','#,0','Sum of positive-sale invoice counts at country × month grain. Cross-grain invoice uniqueness is validated by build checks.'),
 ('Доля суммы отмен','DIVIDE([Сумма отмен], [Продажи до отмен])','0.0%','Cancellation amount / gross sales, not an order cancellation rate.'),
 ('Предыдущий месяц','VAR CurrentMonth = SELECTEDVALUE(\'Calendar\'[MonthIndex]) RETURN IF(NOT ISBLANK(CurrentMonth), CALCULATE([Оборот после отмен], FILTER(ALL(\'Calendar\'), \'Calendar\'[MonthIndex] = CurrentMonth - 1)))','£#,0.00','Prior calendar month, retaining the country filter. Blank if absent or multiple months selected.'),
 ('Изменение м/м','IF(HASONEVALUE(\'Calendar\'[MonthIndex]), DIVIDE([Оборот после отмен] - [Предыдущий месяц], [Предыдущий месяц]))','+0.0%;−0.0%;0.0%','Month-over-month change. Blank for January, missing prior month, or totals.'),
 ('Доля страны','DIVIDE([Оборот после отмен], CALCULATE([Оборот после отмен], ALL(Countries)))','0.0%','Share of all-country net sales for the selected month range; numerator retains country context.'),
 ('Удержание','VAR ObservedRows = FILTER(Cohorts, NOT ISBLANK(Cohorts[ActiveCustomers])) RETURN IF(HASONEVALUE(Cohorts[Age]), DIVIDE(SUMX(ObservedRows, Cohorts[ActiveCustomers]), SUMX(ObservedRows, Cohorts[CohortSize])))','0.0%','Weighted retention for observable windows; blanks excluded from denominator. Totals across ages are blank.'),
 ('Удержание M1','CALCULATE([Удержание], FILTER(ALL(Cohorts), Cohorts[AgeIndex] = 1 && Cohorts[Cohort] >= "2011-01" && Cohorts[Cohort] <= "2011-10"))','0.0%','Fixed weighted M1 across January–October 2011 cohorts; all countries.'),
 ('Размер когорты','IF(HASONEVALUE(Cohorts[Cohort]), MAX(Cohorts[CohortSize]))','#,0','Known CustomerID, first observed positive purchase.')]
sales_table['measures']=[{'name':n,'expression':e,'formatString':f,'description':d,'displayFolder':'Когорты' if 'когорт' in n.lower() or 'Удержание' in n else 'Продажи'} for n,e,f,d in measures]
model={'name':'Retail Analytics','compatibilityLevel':1600,'model':{'culture':'ru-RU','defaultPowerBIDataSourceVersion':'powerBI_V3','sourceQueryCulture':'en-US',
 'dataAccessOptions':{'legacyRedirects':True,'returnErrorValuesAsNull':True},'tables':[sales_table,calendar,countries,cohort],
 'relationships':[{'name':str(uuid.uuid5(uuid.NAMESPACE_URL,'rafif-retail-month')),'fromTable':'Sales','fromColumn':'MonthIndex','toTable':'Calendar','toColumn':'MonthIndex','crossFilteringBehavior':'oneDirection'},
 {'name':str(uuid.uuid5(uuid.NAMESPACE_URL,'rafif-retail-country')),'fromTable':'Sales','fromColumn':'Country','toTable':'Countries','toColumn':'Country','crossFilteringBehavior':'oneDirection'}],
 'annotations':[{'name':'PBI_QueryOrder','value':json.dumps(['Sales','Calendar','Countries','Cohorts'])},{'name':'PBI_ProTooling','value':'["DevMode"]'}]}}
write(MODEL/'model.bim',model)
write(MODEL/'definition.pbism',{'version':'4.0','settings':{'qnaEnabled':False}})
write(DEST/'Retail_Analytics.pbip',{'version':'1.0','artifacts':[{'report':{'path':'Retail.Report'}}],'settings':{'enableAutoRecovery':True}})
write(REPORT/'definition.pbir',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json','version':'4.0','datasetReference':{'byPath':{'path':'../Retail.SemanticModel'}}})
write(REPORT/'definition/version.json',{'$schema':SCHEMA+'versionMetadata/1.0.0/schema.json','version':'4.0.0'})
write(REPORT/'definition/report.json',{'$schema':SCHEMA+'report/2.0.0/schema.json','themeCollection':{},'settings':{'useStylableVisualContainerHeader':True,'exportDataMode':'AllowSummarized','defaultDrillFilterOtherVisuals':True}})
pages=[('sales','01 · Продажи'),('geography','02 · География'),('retention','03 · Удержание')]
write(REPORT/'definition/pages/pages.json',{'$schema':SCHEMA+'pagesMetadata/1.0.0/schema.json','pageOrder':[p for p,_ in pages],'activePageName':'sales'})
INK='#14243A'; TEAL='#087F8C'; MUTED='#58697D'; BG='#F3F6FA'
def lit(v):return {'expr':{'Literal':{'Value':str(v).lower() if isinstance(v,bool) else str(v)+'D' if isinstance(v,(int,float)) else "'"+v.replace("'","''")+"'"}}}
def color(v):return {'solid':{'color':lit(v)}}
def obj(**props):return [{'properties':props}]
def field(table,name,measure=False):return {('Measure' if measure else 'Column'):{'Expression':{'SourceRef':{'Entity':table}},'Property':name}}
def proj(table,name,measure=False):return {'field':field(table,name,measure),'queryRef':table+'.'+name,'nativeQueryRef':name}
def visual(page,name,kind,box,roles=None,title=None,objects=None,sort=None):
    x,y,w,h=box
    v={'visualType':kind,'drillFilterOtherVisuals':True,
       'visualContainerObjects':{'background':obj(show=lit(True),color=color('#FFFFFF'),transparency=lit(0)),
        'border':obj(show=lit(True),color=color('#DFE7EF'),radius=lit(8)),
        'visualHeader':obj(show=lit(False))}}
    if title:v['visualContainerObjects']['title']=obj(show=lit(True),text=lit(title),fontColor=color(INK),fontSize=lit(13),fontFamily=lit('Segoe UI'),bold=lit(True))
    if roles:
        v['query']={'queryState':{r:{'projections':ps} for r,ps in roles.items()}}
        if sort:v['query']['sortDefinition']={'sort':[{'field':sort[0],'direction':sort[1]}]}
    if objects:v['objects']=objects
    write(REPORT/f'definition/pages/{page}/visuals/{page}_{name}/visual.json',{'$schema':SCHEMA+'visualContainer/2.1.0/schema.json','name':page+'_'+name,'position':{'x':x,'y':y,'z':0,'width':w,'height':h,'tabOrder':0},'visual':v})
def text(page,name,content,box,size=14,bold=False):
    visual(page,name,'textbox',box,objects={'general':obj(paragraphs=[{'textRuns':[{'value':content,'textStyle':{'fontFamily':'Segoe UI','fontSize':str(size)+'pt','color':INK,'fontWeight':'bold' if bold else 'normal'}}]}])})
def card(page,name,measure,title,x,y,w=280):
    visual(page,name,'card',(x,y,w,116),{'Values':[proj('Sales',measure,True)]},title,
      {'labels':obj(color=color(TEAL),fontSize=lit(27),labelDisplayUnits=lit(1),labelPrecision=lit(0 if measure=='Заказы' else 1)),
       'categoryLabels':obj(show=lit(False))})
for page,label in pages:
    write(REPORT/f'definition/pages/{page}/page.json',{'$schema':SCHEMA+'page/2.0.0/schema.json','name':page,'displayName':label,'displayOption':'FitToPage','width':1280,'height':800,'objects':{'background':obj(color=color(BG),transparency=lit(0))}})
    text(page,'title','RETAIL ANALYTICS  /  '+label.split(' · ')[1].upper(),(24,16,1232,55),24,True)
    text(page,'footnote','UCI Online Retail · Chen (2015), CC BY 4.0 · Январь–ноябрь 2011 · Открытые данные · Рафиф Алшауи',(24,758,1232,30),10)
for page in ['sales','geography']:
    visual(page,'country','slicer',(24,82,600,76),{'Values':[proj('Countries','Country')]},'Страна',{'data':obj(mode=lit('Dropdown')),'selection':obj(singleSelect=lit(False),selectAllCheckboxEnabled=lit(True))})
    visual(page,'month','slicer',(640,82,616,76),{'Values':[proj('Calendar','Month')]},'Месяц',{'data':obj(mode=lit('Dropdown'))},sort=(field('Calendar','Month'),'Ascending'))
card('sales','net','Оборот после отмен','Оборот после отмен, GBP',24,174,400)
card('sales','orders','Заказы','Заказы с продажами',440,174,400)
card('sales','cancel','Доля суммы отмен','Сумма отмен / продажи',856,174,400)
visual('sales','trend','lineChart',(24,306,794,350),{'Category':[proj('Calendar','Month')],'Y':[proj('Sales','Оборот после отмен',True),proj('Sales','Продажи до отмен',True)]},'Динамика продаж, GBP',{'categoryAxis':obj(showAxisTitle=lit(False)),'valueAxis':obj(showAxisTitle=lit(False))},(field('Calendar','Month'),'Ascending'))
visual('sales','month_table','tableEx',(834,306,422,350),{'Values':[proj('Calendar','Month'),proj('Sales','Оборот после отмен',True),proj('Sales','Изменение м/м',True)]},'Изменение месяц к месяцу',sort=(field('Calendar','Month'),'Ascending'))
text('sales','method','Метрика оборота: продажи минус отмены. Это не прибыль. Неполный декабрь 2011 исключён; фильтры страны и месяца действуют на все показатели этой страницы.',(24,674,1232,65),12)
card('geography','net','Оборот после отмен','Оборот выбранных стран, GBP',24,174,400)
card('geography','share','Доля страны','Доля в обороте всех стран',440,174,400)
card('geography','cancel','Доля суммы отмен','Сумма отмен / продажи',856,174,400)
visual('geography','countries','clusteredBarChart',(24,306,600,370),{'Category':[proj('Countries','Country')],'Y':[proj('Sales','Оборот после отмен',True)]},'Оборот по странам, GBP',sort=(field('Sales','Оборот после отмен',True),'Descending'))
visual('geography','country_table','tableEx',(640,306,616,370),{'Values':[proj('Countries','Country'),proj('Sales','Заказы',True),proj('Sales','Оборот после отмен',True),proj('Sales','Доля суммы отмен',True)]},'Страны: объём и отмены',sort=(field('Sales','Оборот после отмен',True),'Descending'))
text('geography','method','Великобритания даёт 83,2% оборота за весь период. Для сравнения остальных рынков выберите страны в фильтре. Доля страны считается относительно всех стран в выбранные месяцы.',(24,690,1232,55),12)
card('retention','m1','Удержание M1','Взвешенное удержание M1',24,86,400)
text('retention','scope','Все страны · когорты январь–октябрь 2011\nM1 = повторные покупатели / размер доступных когорт.\nФильтры страниц продаж здесь не применяются.',(440,86,816,116),15)
visual('retention','matrix','pivotTable',(24,220,1232,360),{'Rows':[proj('Cohorts','Cohort')],'Columns':[proj('Cohorts','Age')],'Values':[proj('Sales','Удержание',True)]},'Первая наблюдаемая покупка → повторная покупка',{'rowSubtotals':obj(show=lit(False)),'columnSubtotals':obj(show=lit(False))},(field('Cohorts','Cohort'),'Ascending'))
text('retention','limits','Границы интерпретации\n• Только клиенты с известным CustomerID; продажи без ID остаются в финансовых итогах.\n• Пустая ячейка — окно ещё не наступило. Нулевое удержание — покупок в наблюдаемом окне нет.\n• Декабрь 2010 используется как история: первая наблюдаемая покупка не обязательно первая в жизни клиента.\n• Отчёт описывает исторические данные и не доказывает причинный эффект бизнес-действий.',(24,596,1232,146),13)
DEST.mkdir(exist_ok=True)
(DEST/'measures.dax').write_text('\n\n'.join('// '+d+'\n'+n+' =\n'+e for n,e,_,d in measures),encoding='utf-8')
(DEST/'.gitignore').write_text('**/.pbi/localSettings.json\n**/.pbi/cache.abf\n',encoding='utf-8')
(DEST/'README.txt').write_text('''POWER BI · RETAIL ANALYTICS
Рафиф Алшауи · Портфолио аналитика данных

ОТКРЫТИЕ
1. Распакуйте весь ZIP, сохранив структуру папок.
2. Откройте Retail_Analytics.pbip в актуальном Power BI Desktop.
3. Нажмите «Обновить / Refresh», чтобы загрузить встроенные данные в модель.
   Доступ к файлам компьютера, сервисам и учётным записям не нужен.
4. Три страницы: продажи, география, удержание. В первых двух работают
   срезы страны и месяца. Страница удержания имеет фиксированный охват.

ФОРМАТ И СТАТУС ПРОВЕРКИ
Это редактируемый проект PBIP: отчёт PBIR и семантическая модель TMSL.
Исходные определения JSON проверены по официальным схемам Microsoft.
Контрольные значения сверены с SQL и Python. Power BI Desktop в среде
сборки не установлен: запуск, рендеринг визуализаций и DAX-исполнение
в Desktop ещё не проверены. Файл PBIX в комплект не входит.

МОДЕЛЬ
Sales: 269 строк; одна строка на страну и месяц, январь–ноябрь 2011.
Countries и Calendar — измерения, фильтрация в одну сторону к Sales.
Cohorts — отдельная таблица M0–M5 по всем странам. Не соединена с Sales,
чтобы фильтр страны не создавал неверное впечатление о фильтрации когорт.
Денежные суммы — целые пенсы. Визуальные меры переводят их в GBP.
Power Query M содержит встроенные CSV-снимки. Чтобы обновить снимок:
python analyze.py, затем python build_powerbi.py из родительской папки.

КОНТРОЛЬНЫЕ ЗНАЧЕНИЯ
Все страны, январь–ноябрь 2011: 17 582 заказа; £8 587 247,02 после отмен;
£9 204 145,72 до отмен; £616 898,70 отмен; отношение отмен 6,7024%.
Германия, весь период: 410 заказов; £199 330,67 после отмен.
Германия, январь–март: 82 заказа; £39 590,69 после отмен.
Взвешенное M1, когорты января–октября: 19,9417%.

ИСТОЧНИК И ОГРАНИЧЕНИЯ
Chen, D. (2015). Online Retail. UCI Machine Learning Repository.
https://doi.org/10.24432/C5BW33 · лицензия CC BY 4.0.
Открытые исторические данные; не данные работодателя.
Исходно 541 909 строк; строки без положительной цены исключены.
Пропуски CustomerID исключены только из когорт, не из продаж.
Совпадающие строки сохранены: в источнике нет надёжного ID строки.
Неполный декабрь 2011 исключён. Оборот не равен прибыли.
Подробности, SQL, проверки и полный конвейер — в общем архиве портфолио.
''',encoding='utf-8')
print(json.dumps({'project':str(DEST/'Retail_Analytics.pbip'),'tables':len(model['model']['tables']),'measures':len(measures),'pages':len(pages),'sales_rows':len(sales),'cohort_rows':len(cohorts)},ensure_ascii=False))
