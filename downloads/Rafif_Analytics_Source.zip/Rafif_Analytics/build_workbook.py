"""Build the retail Excel workbook using the public openpyxl package.

Reproduce from an existing results/dashboard_data.json (Python 3.10+):
    python -m pip install openpyxl==3.1.5
    python build_workbook.py --output ../output/excel-openpyxl/Retail_Analytics.xlsx

Use analyze.py first to recompute the JSON from the source dataset. The default
output is deliberately separate from the published excel/Retail_Analytics.xlsx.
The three existing sheets, SUMIFS/SUMPRODUCT formulas, country selector, cohort
heatmap and two native charts are preserved. openpyxl writes formulas but does
not evaluate them: open the result in Excel/LibreOffice, allow recalculation and
save it before using a viewer that relies on cached formula results. The optional
--checks file records source reconciliations and structure only, not an Excel
calculation or visual validation. No private runtime or Node package is needed.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import CharacterProperties, Font as DrawingFont, Paragraph, ParagraphProperties
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.workbook.properties import CalcProperties

ROOT = Path(__file__).resolve().parent
INK, BLUE, MUTED = "223449", "295788", "596579"
MONTHS = '"янв","фев","мар","апр","май","июн","июл","авг","сен","окт","ноя","дек"'


def month_date(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m")


def source_checks(data: dict) -> dict:
    """Compare country-month inputs with independently published monthly totals."""
    cm, monthly, cohorts = data["country_month"], data["monthly"], data["cohorts"]
    assert len({(r["country"], r["month"]) for r in cm}) == len(cm), "Duplicate country-month key"
    assert len({(r["cohort"], r["age"]) for r in cohorts}) == len(cohorts), "Duplicate cohort-age key"
    grouped = defaultdict(lambda: defaultdict(int))
    for row in cm:
        assert row["net_pence"] == row["gross_pence"] - row["cancellations_pence"]
        for key in ("net_pence", "gross_pence", "cancellations_pence", "orders"):
            grouped[row["month"]][key] += row[key]
    assert set(grouped) == {r["month"] for r in monthly}, "Monthly coverage differs"
    for row in monthly:
        for key in ("net_pence", "gross_pence", "cancellations_pence", "orders"):
            assert grouped[row["month"]][key] == row[key], (row["month"], key)
    total_pence = sum(row["net_pence"] for row in cm)
    assert total_pence == round(data["totals"]["net_gbp"] * 100)
    assert sum(row["orders"] for row in cm) == data["totals"]["orders"]
    first, last = monthly[0]["month"], monthly[-1]["month"]
    m1 = [r for r in cohorts if r["age"] == 1 and first <= r["cohort"] < last]
    weighted_m1 = sum(r["active_customers"] for r in m1) / sum(r["cohort_size"] for r in m1)
    assert abs(weighted_m1 - data["totals"]["m1_weighted_retention"]) < 1e-12
    assert next(r for r in cohorts if r["cohort"] == last and r["age"] == 1)["active_customers"] is None
    return {"country_month_rows": len(cm), "monthly_rows": len(monthly), "cohort_rows": len(cohorts),
            "net_gbp": total_pence / 100, "orders": data["totals"]["orders"],
            "weighted_m1": weighted_m1, "future_m1_is_null": True}


def base(ws, last_row: int, last_col: int) -> None:
    ws.sheet_view.showGridLines = True  # Preserve the existing workbook's grid setting.
    for row in ws.iter_rows(min_row=1, max_row=last_row, max_col=last_col):
        for cell in row:
            cell.font = Font(name="Arial", size=11, color=INK)
            cell.alignment = Alignment(vertical="center")
    for row in range(1, last_row + 1):
        ws.row_dimensions[row].height = 22
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_view.zoomScale = 85


def widths(ws, values: dict[str, float]) -> None:
    for column, width in values.items():
        ws.column_dimensions[column].width = width


def header(ws, row: int, values: list, start: int = 1) -> None:
    ws.row_dimensions[row].height = 38
    for col, value in enumerate(values, start):
        cell = ws.cell(row, col, value)
        cell.font = Font(name="Arial", size=11, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=BLUE)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def title(ws, text: str, subtitle: str) -> None:
    ws["A2"], ws["A3"] = text, subtitle
    ws["A2"].font = Font(name="Arial", size=16, bold=True, color=INK)
    ws.row_dimensions[2].height = 30
    note(ws, "A3")
    ws.sheet_properties.tabColor = BLUE


def note(ws, address: str) -> None:
    ws[address].font = Font(name="Arial", size=10, italic=True, color=MUTED)


def table(ws, name: str, reference: str) -> None:
    item = Table(displayName=name, ref=reference)
    item.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws.add_table(item)


def line_chart(ws, title_text: str, labels_col: int, values_col: int, first_row: int,
               last_row: int, anchor: str, percentage: bool = False) -> None:
    chart = LineChart()
    chart.title, chart.legend = title_text, None
    chart.add_data(Reference(ws, min_col=values_col, min_row=first_row - 1, max_row=last_row), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=labels_col, min_row=first_row, max_row=last_row))
    chart.width, chart.height = 15, 11
    chart.y_axis.numFmt = "0%" if percentage else "#,##0"
    if percentage:
        chart.y_axis.scaling.min = 0
    chart.x_axis.tickLblPos = "low"
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    chart.x_axis.axPos, chart.y_axis.axPos = "b", "l"
    chart.x_axis.txPr = RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=CharacterProperties(latin=DrawingFont(typeface="Arial"), sz=1000)))])
    chart.y_axis.txPr = RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=CharacterProperties(latin=DrawingFont(typeface="Arial"), sz=1000)))])
    chart.series[0].graphicalProperties.line.solidFill = BLUE
    chart.series[0].graphicalProperties.line.width = 25400
    chart.series[0].smooth = False
    chart.display_blanks = "gap"
    ws.add_chart(chart, anchor)


def build(data: dict) -> Workbook:
    wb = Workbook()
    sales = wb.active
    sales.title = "Продажи"
    cohorts, source = wb.create_sheet("Когорты"), wb.create_sheet("Данные")
    wb.calculation = CalcProperties(calcMode="auto", fullCalcOnLoad=True, forceFullCalc=True)
    wb.properties.title = "Продажи и повторные покупки — UCI Online Retail"
    wb.properties.creator = ""
    cm, months, cohort_data = data["country_month"], data["monthly"], data["cohorts"]
    assert [r["month"] for r in months] == sorted(r["month"] for r in months)
    # The original dashboard layout is an eleven-month view, not an arbitrary input template.
    assert [r["month"] for r in months] == [f"2011-{month:02d}" for month in range(1, 12)], "Expected January-November 2011; revise layout for a different period"
    cohort_keys = sorted({r["cohort"] for r in cohort_data})
    assert len(cohort_keys) == 12, "Expected twelve observed cohorts"
    last, cohort_last = 6 + len(cm), 6 + len(cohort_data)
    countries = ["Все страны", *sorted({r["country"] for r in cm})]

    base(source, last, 16)
    widths(source, {"A": 16, "B": 23, **{x: 17 for x in "CDEF"}, "G": 3, "H": 3,
                    **{x: 16 for x in "IJKL"}, "M": 3, "N": 24})
    source["A1"] = "Подготовленные данные из SQL-расчётов"
    source["A1"].font = Font(name="Arial", size=16, bold=True, color=INK)
    source["A3"] = "Источник: Chen, D. (2015), UCI Online Retail, DOI 10.24432/C5BW33, CC BY 4.0."
    source["A4"] = "https://archive.ics.uci.edu/dataset/352/online%2Bretail"
    source["A4"].hyperlink = source["A4"].value
    source["I3"] = "Агрегаты очищенных операций; SQL и исходные данные описаны в README."
    source["I4"] = "Январь–ноябрь 2011. Отмены: отрицательное количество, положительная цена."
    header(source, 6, ["Месяц", "Страна", "Заказы", "Продажи, GBP", "Отмены, GBP", "Оборот SQL, GBP"])
    for row_index, row in enumerate(cm, 7):
        values = [month_date(row["month"]), row["country"], row["orders"], row["gross_pence"] / 100,
                  row["cancellations_pence"] / 100, row["net_pence"] / 100]
        for col, value in enumerate(values, 1):
            source.cell(row_index, col, value)
        source.cell(row_index, 1).number_format = "mmm yyyy"
        source.cell(row_index, 3).number_format = "#,##0"
        for col in (4, 5, 6):
            source.cell(row_index, col).number_format = "#,##0.00"
    header(source, 6, ["Когорта", "Возраст, мес.", "Клиентов", "Активных"], 9)
    for row_index, row in enumerate(cohort_data, 7):
        for col, value in enumerate([month_date(row["cohort"]), row["age"], row["cohort_size"], row["active_customers"]], 9):
            source.cell(row_index, col, value)
        source.cell(row_index, 9).number_format = "mmm yyyy"
    header(source, 6, ["Выбор страны"], 14)
    for row_index, country in enumerate(countries, 7):
        source.cell(row_index, 14, country)
    table(source, "CountryMonthInputs", f"A6:F{last}")
    table(source, "CohortInputs", f"I6:L{cohort_last}")
    source.freeze_panes = "C7"
    source.print_title_rows = "1:6"
    source.print_area = f"A1:N{last}"
    source.page_setup.fitToHeight = 0

    base(sales, 41, 17)
    widths(sales, {"A": 15, **{x: 17 for x in "BCD"}, "E": 13, "F": 16, "G": 16,
                   "H": 3, **{x: 9 for x in "IJKLMNOPQ"}})
    title(sales, "Продажи и отмены", "Январь–ноябрь 2011. Денежные показатели в GBP.")
    sales["A5"], sales["B5"] = "Страна", "Все страны"
    sales["B5"].fill = PatternFill("solid", fgColor="FFF2CC")
    wb.defined_names.add(DefinedName("CountrySelection", attr_text=f"'Данные'!$N$7:$N${6 + len(countries)}"))
    selector = DataValidation(type="list", formula1="=CountrySelection", allow_blank=False)
    selector.showErrorMessage, selector.errorTitle, selector.error = True, "Выберите страну", "Используйте значение из списка."
    sales.add_data_validation(selector)
    selector.add(sales["B5"])
    sales["D5"] = "Меняйте страну в B5: таблица и диаграмма пересчитываются."
    note(sales, "D5")
    for label, cell, value_cell, formula, number_format in [
        ("Оборот после отмен", "A7", "A8", "=D24", '"£"#,##0'),
        ("Заказы с продажами", "D7", "D8", "=E24", "#,##0"),
        ("Отмены / продажи", "F7", "F8", "=F24", "0.0%"),
    ]:
        sales[cell], sales[value_cell] = label, formula
        sales[value_cell].font = Font(name="Arial", size=16, bold=True, color=INK)
        sales[value_cell].number_format = number_format
    sales.merge_cells("A8:C8")
    sales["A8"].alignment = Alignment(horizontal="left", vertical="center")
    header(sales, 11, ["Месяц", "Продажи, GBP", "Отмены, GBP", "Оборот, GBP", "Заказы", "Отмены / продажи", "Оборот к пред. мес."])

    def sum_formula(column: str, row: int) -> str:
        value_range, dates, country_range = f"'Данные'!${column}$7:${column}${last}", f"'Данные'!$A$7:$A${last}", f"'Данные'!$B$7:$B${last}"
        return f'=IF($B$5="Все страны",SUMIFS({value_range},{dates},$A{row}),SUMIFS({value_range},{dates},$A{row},{country_range},$B$5))'

    for row_index, month in enumerate(months, 12):
        sales.cell(row_index, 1, month_date(month["month"])).number_format = "mmm yyyy"
        formulas = [sum_formula("D", row_index), sum_formula("E", row_index), f"=B{row_index}-C{row_index}",
                    sum_formula("C", row_index), f'=IF(B{row_index}=0,"",C{row_index}/B{row_index})',
                    f'=IF(D{row_index-1}=0,"",D{row_index}/D{row_index-1}-1)' if row_index > 12 else '=""']
        for col, formula in enumerate(formulas, 2):
            sales.cell(row_index, col, formula)
    sales["A24"] = "Итого"
    for column in "BCDE":
        sales[f"{column}24"] = f"=SUM({column}12:{column}22)"
    sales["F24"] = '=IF(B24=0,"",C24/B24)'
    for row in sales.iter_rows(min_row=12, max_row=24, min_col=2, max_col=7):
        for cell in row:
            cell.number_format = "#,##0.00" if cell.column <= 4 else "#,##0" if cell.column == 5 else "0.0%"
    for cell in sales[24][:7]:
        cell.font = Font(name="Arial", size=11, bold=True, color=INK)
        cell.border = Border(top=Side(style="thin", color=BLUE))
    sales["A26"] = "Оборот = продажи минус отмены. Отношение сумм отмен и продаж не равно доле возвращённых заказов."
    sales["A27"] = "Декабрь 2011 исключён как неполный. Оборот не равен прибыли: затраты отсутствуют в источнике."
    note(sales, "A26")
    note(sales, "A27")
    sales["I30"], sales["J30"] = "Месяц", "Оборот, GBP"
    for row_index in range(31, 42):
        sales.cell(row_index, 9, f"=CHOOSE(MONTH(A{row_index-19}),{MONTHS})")
        sales.cell(row_index, 10, f"=D{row_index-19}").number_format = "#,##0.00"
    line_chart(sales, "Оборот после отмен, GBP", 9, 10, 31, 41, "I7")
    sales.print_area = "A1:Q27"

    base(cohorts, 37, 17)
    widths(cohorts, {"A": 16, "B": 12, **{x: 11 for x in "CDEFGH"}, "I": 3, **{x: 11 for x in "JKLMNOPQ"}})
    title(cohorts, "Повторные покупки по когортам", "Первая наблюдаемая покупка. Все страны. Только известные CustomerID.")
    cohorts["A5"], cohorts["D5"] = "Возврат к покупке в M1", "=SUMPRODUCT(B10:B19,D10:D19)/SUM(B10:B19)"
    cohorts["D5"].number_format = "0.0%"
    cohorts["D5"].font = Font(name="Arial", size=16, bold=True, color=INK)
    cohorts["F5"] = "Взвешенно: январь–октябрь 2011"
    note(cohorts, "F5")
    header(cohorts, 8, ["Когорта", "Клиентов", 0, 1, 2, 3, 4, 5])
    for col in range(3, 9):
        cohorts.cell(8, col).number_format = '"M"0'
    end = month_date(months[-1]["month"])
    for row_index, cohort in enumerate(cohort_keys, 9):
        cohorts.cell(row_index, 1, month_date(cohort)).number_format = "mmm yyyy"
        cohorts.cell(row_index, 2, f"=SUMIFS('Данные'!$K$7:$K${cohort_last},'Данные'!$I$7:$I${cohort_last},$A{row_index},'Данные'!$J$7:$J${cohort_last},0)").number_format = "#,##0"
        for col in range(3, 9):
            letter = get_column_letter(col)
            cohorts.cell(row_index, col, f'=IF(EDATE($A{row_index},{letter}$8)>DATE({end.year},{end.month},1),"",SUMIFS(\'Данные\'!$L$7:$L${cohort_last},\'Данные\'!$I$7:$I${cohort_last},$A{row_index},\'Данные\'!$J$7:$J${cohort_last},{letter}$8)/$B{row_index})').number_format = "0.0%"
    cohorts.conditional_formatting.add("C9:H20", ColorScaleRule(start_type="num", start_value=0, start_color="F3F6FA", mid_type="num", mid_value=0.25, mid_color="ADC5E0", end_type="num", end_value=1, end_color="386B9C"))
    for address, value in {"A23": "M0 = месяц первой наблюдаемой покупки. M1 = следующий календарный месяц.",
                           "A24": "Пустые ячейки: окно наблюдения не завершено. Это не нулевое удержание.",
                           "A25": "Пропуски CustomerID исключены только из когорт; суммы продаж учитывают такие операции."}.items():
        cohorts[address] = value
        note(cohorts, address)
    cohorts["J27"], cohorts["K27"] = "Когорта", "Повторная покупка M1"
    for row_index in range(28, 38):
        cohorts.cell(row_index, 10, f"=CHOOSE(MONTH(A{row_index-18}),{MONTHS})")
        cohorts.cell(row_index, 11, f"=D{row_index-18}").number_format = "0.0%"
    line_chart(cohorts, "Повторная покупка в M1", 10, 11, 28, 37, "J8", percentage=True)
    cohorts.print_area = "A1:Q25"
    return wb


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data", type=Path, default=ROOT / "results/dashboard_data.json")
    parser.add_argument("--output", type=Path, default=ROOT.parent / "output/excel-openpyxl/Retail_Analytics.xlsx")
    parser.add_argument("--checks", type=Path, help="Write source/structure checks as JSON; no formula-engine claim")
    args = parser.parse_args()
    data_bytes = args.data.read_bytes()
    data = json.loads(data_bytes)["retail"]
    checks = source_checks(data)
    wb = build(data)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(args.output)
    reopened = load_workbook(args.output, data_only=False)
    assert reopened.sheetnames == ["Продажи", "Когорты", "Данные"]
    assert reopened["Продажи"]["B5"].value == "Все страны"
    assert reopened["Продажи"]["D24"].value == "=SUM(D12:D22)"
    assert len(reopened["Продажи"]._charts) == len(reopened["Когорты"]._charts) == 1
    assert set(reopened["Данные"].tables) == {"CountryMonthInputs", "CohortInputs"}
    checks.update({"checked_at_utc": datetime.now(timezone.utc).isoformat(),
                   "input_sha256": hashlib.sha256(data_bytes).hexdigest(),
                   "output_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                   "reopened_structure": "passed", "formula_calculation": "not_performed_by_openpyxl",
                   "visual_validation": "not_performed_by_generator"})
    reopened.close()
    if args.checks:
        args.checks.parent.mkdir(parents=True, exist_ok=True)
        args.checks.write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), **checks}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
