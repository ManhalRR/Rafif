import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(root,'excel');
await fs.mkdir(out,{recursive:true});
const data=JSON.parse(await fs.readFile(path.join(root,'results/dashboard_data.json'),'utf8')).retail;
const wb=Workbook.create();
const sales=wb.worksheets.add('Продажи');
const cohorts=wb.worksheets.add('Когорты');
const source=wb.worksheets.add('Данные');
const ink='#223449',blue='#295788',muted='#596579';
function base(sheet,range){
  sheet.showGridLines=true;
  sheet.getRange(range).format.font={name:'Arial',size:11,color:ink};
  sheet.getRange(range).format.rowHeight=22;
  sheet.getRange(range).format.verticalAlignment='center';
}
function title(sheet,title,context){
  sheet.getRange('A2').values=[[title]];
  sheet.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:ink};
  sheet.getRange('A2:O2').format.rowHeight=30;
  sheet.getRange('A3').values=[[context]];
  sheet.getRange('A3').format.font={italic:true,color:muted,size:10};
}
function head(sheet,range){
  sheet.getRange(range).format={fill:blue,font:{name:'Arial',bold:true,color:'#FFFFFF',size:11},horizontalAlignment:'center',wrapText:true,rowHeight:38};
}
function chartStyle(chart,title,a,b){
  chart.title=title; chart.titleTextStyle.typeface='Arial'; chart.titleTextStyle.fontSize=15;
  chart.hasLegend=false; chart.setPosition(a,b);
  chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:11}};
  chart.yAxis={numberFormatCode:'#,##0',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:11}};
  chart.series.items[0].line={fill:blue,style:'solid',width:2};
}
base(source,'A1:P277');
source.getRange('A1').values=[['Подготовленные данные из SQL-расчётов']];
source.getRange('A1').format.font={bold:true,size:16};
source.getRange('A3').values=[['Источник: Chen, D. (2015), UCI Online Retail, DOI 10.24432/C5BW33, CC BY 4.0.']];
source.getRange('A4').values=[['https://archive.ics.uci.edu/dataset/352/online%2Bretail']];
source.getRange('I3').values=[['Агрегаты очищенных операций. Исходный XLSX и SQL входят в комплект.']];
source.getRange('I4').values=[['Продажи за январь-ноябрь 2011. Отмены: отрицательное количество, положительная цена.']];
source.getRange('A6:F6').values=[['Месяц','Страна','Заказы','Продажи, GBP','Отмены, GBP','Оборот SQL, GBP']];
const cm=data.country_month;
const last=6+cm.length;
source.getRange(`A7:F${last}`).values=cm.map(r=>[new Date(`${r.month}-01T00:00:00Z`),r.country,r.orders,r.gross_pence/100,r.cancellations_pence/100,r.net_pence/100]);
source.getRange(`A7:A${last}`).setNumberFormat('mmm yyyy');
source.getRange(`C7:C${last}`).setNumberFormat('#,##0');
source.getRange(`D7:F${last}`).setNumberFormat('#,##0.00');
source.getRange('A1:A277').format.columnWidth=16;
source.getRange('B1:B277').format.columnWidth=23;
source.getRange('C1:F277').format.columnWidth=17;
source.getRange('G1:G277').format.columnWidth=3;
source.getRange('H1:H277').format.columnWidth=3;
source.getRange('I1:L80').format.columnWidth=16;
source.getRange('N1:N50').format.columnWidth=24;
source.getRange('I6:L6').values=[['Когорта','Возраст, мес.','Клиентов','Активных']];
source.getRange('I7:L78').values=data.cohorts.map(r=>[new Date(`${r.cohort}-01T00:00:00Z`),r.age,r.cohort_size,r.active_customers]);
source.getRange('I7:I78').setNumberFormat('mmm yyyy');
source.getRange('J7:L78').setNumberFormat('#,##0');
source.getRange('N6').values=[['Выбор страны']];
const countries=['Все страны',...data.countries.map(x=>x.country).sort()];
source.getRange(`N7:N${6+countries.length}`).values=countries.map(x=>[x]);
head(source,'A6:F6');head(source,'I6:L6');head(source,'N6');
source.tables.add(`A6:F${last}`,true,'CountryMonthInputs');
source.tables.add('I6:L78',true,'CohortInputs');
source.freezePanes.freezeRows(6);

base(sales,'A1:O29'); sales.tabColor=blue;
sales.getRange('A1:A29').format.columnWidth=15;
sales.getRange('B1:D29').format.columnWidth=17;
sales.getRange('E1:E29').format.columnWidth=13;
sales.getRange('F1:G29').format.columnWidth=16;
sales.getRange('H1:H29').format.columnWidth=3;
sales.getRange('I1:O29').format.columnWidth=9;
title(sales,'Продажи и отмены','Январь-ноябрь 2011. Денежные показатели в GBP.');
sales.getRange('A5').values=[['Страна']]; sales.getRange('B5').values=[['Все страны']];
sales.getRange('B5').format.fill='#FFF2CC';
sales.getRange('B5').dataValidation={rule:{type:'list',formula1:`'Данные'!$N$7:$N$${6+countries.length}`}};
sales.getRange('D5').values=[['Меняйте страну в B5: таблица и диаграмма пересчитываются.']];
sales.getRange('D5').format.font={size:10,italic:true,color:muted};
sales.getRange('A7').values=[['Оборот после отмен']]; sales.getRange('D7').values=[['Заказы с продажами']]; sales.getRange('F7').values=[['Отмены / продажи']];
sales.getRange('A8').formulas=[['=D24']];sales.getRange('D8').formulas=[['=E24']];sales.getRange('F8').formulas=[['=F24']];
sales.getRange('A8:G8').format.font={size:16,bold:true};
sales.getRange('A8').setNumberFormat('"£"#,##0');sales.getRange('D8').setNumberFormat('#,##0');sales.getRange('F8').setNumberFormat('0.0%');
sales.getRange('A11:G11').values=[['Месяц','Продажи, GBP','Отмены, GBP','Оборот, GBP','Заказы','Отмены / продажи','Оборот к пред. мес.']];head(sales,'A11:G11');
sales.getRange('A12:A22').values=data.monthly.map(r=>[new Date(`${r.month}-01T00:00:00Z`)]);sales.getRange('A12:A22').setNumberFormat('mmm yyyy');
const sum=(col,row)=>`IF($B$5="Все страны",SUMIFS('Данные'!$${col}$7:$${col}$${last},'Данные'!$A$7:$A$${last},$A${row}),SUMIFS('Данные'!$${col}$7:$${col}$${last},'Данные'!$A$7:$A$${last},$A${row},'Данные'!$B$7:$B$${last},$B$5))`;
sales.getRange('B12:G22').formulas=data.monthly.map((r,i)=>{const row=i+12;return['='+sum('D',row),'='+sum('E',row),`=B${row}-C${row}`,'='+sum('C',row),`=IF(B${row}=0,"",C${row}/B${row})`,i?`=IF(D${row-1}=0,"",D${row}/D${row-1}-1)`:'=""'];});
sales.getRange('A24').values=[['Итого']];
sales.getRange('B24:F24').formulas=[['=SUM(B12:B22)','=SUM(C12:C22)','=SUM(D12:D22)','=SUM(E12:E22)','=IF(B24=0,"",C24/B24)']];
sales.getRange('B12:D24').setNumberFormat('#,##0.00');sales.getRange('E12:E24').setNumberFormat('#,##0');sales.getRange('F12:G24').setNumberFormat('0.0%');
sales.getRange('A24:G24').format.font={bold:true};sales.getRange('A24:G24').format.borders={top:{style:'thin',color:blue}};
sales.getRange('A26').values=[['Оборот = продажи минус отмены. Отношение сумм отмен и продаж не равно доле возвращённых заказов.']];
sales.getRange('A27').values=[['Декабрь 2011 исключён как неполный. Оборот не равен прибыли: затраты отсутствуют в источнике.']];
sales.getRange('A26:A27').format.font={size:10,color:muted};
// Text month labels avoid Excel serial-date labels in previews and exports.
sales.getRange('I27:J27').values=[['Месяц','Оборот, GBP']];
const monthLabel=cell=>`=CHOOSE(MONTH(${cell}),"янв","фев","мар","апр","май","июн","июл","авг","сен","окт","ноя","дек")`;
sales.getRange('I28:J38').formulas=data.monthly.map((r,i)=>[monthLabel(`A${12+i}`),`=D${12+i}`]);
const trend=sales.charts.add('line',sales.getRange('I27:J38'));
chartStyle(trend,'Оборот после отмен, GBP','I7','P24');

base(cohorts,'A1:O30');cohorts.tabColor=blue;
cohorts.getRange('A1:A30').format.columnWidth=16;cohorts.getRange('B1:B30').format.columnWidth=12;
cohorts.getRange('C1:H30').format.columnWidth=11;cohorts.getRange('I1:I30').format.columnWidth=3;
cohorts.getRange('J1:O30').format.columnWidth=11;
title(cohorts,'Повторные покупки по когортам','Первая наблюдаемая покупка. Все страны. Только известные CustomerID.');
cohorts.getRange('A5').values=[['Возврат к покупке в M1']];cohorts.getRange('D5').formulas=[['=SUMPRODUCT(B10:B19,D10:D19)/SUM(B10:B19)']];
cohorts.getRange('D5').setNumberFormat('0.0%');cohorts.getRange('D5').format.font={size:16,bold:true};
cohorts.getRange('F5').values=[['Взвешенно: январь-октябрь 2011']];cohorts.getRange('F5').format.font={size:10,color:muted};
cohorts.getRange('A8:H8').values=[['Когорта','Клиентов',0,1,2,3,4,5]];head(cohorts,'A8:H8');cohorts.getRange('C8:H8').setNumberFormat('"M"0');
const cohortKeys=[...new Set(data.cohorts.map(r=>r.cohort))];
cohorts.getRange('A9:A20').values=cohortKeys.map(x=>[new Date(`${x}-01T00:00:00Z`)]);cohorts.getRange('A9:A20').setNumberFormat('mmm yyyy');
cohorts.getRange('B9:B20').formulas=cohortKeys.map((_,i)=>[`=SUMIFS('Данные'!$K$7:$K$78,'Данные'!$I$7:$I$78,$A${i+9},'Данные'!$J$7:$J$78,0)`]);
cohorts.getRange('C9:H20').formulas=cohortKeys.map((_,i)=>['C','D','E','F','G','H'].map(c=>`=IF(EDATE($A${i+9},${c}$8)>DATE(2011,11,1),"",SUMIFS('Данные'!$L$7:$L$78,'Данные'!$I$7:$I$78,$A${i+9},'Данные'!$J$7:$J$78,${c}$8)/$B${i+9})`));
cohorts.getRange('B9:B20').setNumberFormat('#,##0');cohorts.getRange('C9:H20').setNumberFormat('0.0%');
cohorts.getRange('C9:H20').conditionalFormats.add('colorScale',{colors:['#F3F6FA','#ADC5E0','#386B9C'],thresholds:[0,0.25,1]});
cohorts.getRange('A23').values=[['M0 = месяц первой наблюдаемой покупки. M1 = следующий календарный месяц.']];
cohorts.getRange('A24').values=[['Пустые ячейки: окно наблюдения не завершено. Это не нулевое удержание.']];
cohorts.getRange('A25').values=[['Пропуски CustomerID исключены только из когорт; суммы продаж учитывают такие операции.']];
cohorts.getRange('A23:A25').format.font={size:10,color:muted};
cohorts.getRange('J27:K27').values=[['Когорта','Повторная покупка M1']];
cohorts.getRange('J28:K37').formulas=cohortKeys.slice(1,11).map((_,i)=>[monthLabel(`A${i+10}`),`=D${i+10}`]);
const retention=cohorts.charts.add('line',cohorts.getRange('J27:K37'));
chartStyle(retention,'Повторная покупка в M1','J8','Q21');
retention.yAxis={numberFormatCode:'0%',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:11}};

// Independent controls use the existing SQL/Python results, not mirrored formulas.
wb.recalculate();
function num(sheet,cell){return sheet.getRange(cell).values[0][0];}
function close(actual,expected,tol=0.005){assert.equal(typeof actual,'number');assert.ok(Math.abs(actual-expected)<=tol,`${actual} != ${expected}`);}
close(num(sales,'D24'),data.totals.net_gbp);close(num(sales,'E24'),data.totals.orders,0);
close(num(cohorts,'D5'),data.totals.m1_weighted_retention,1e-12);
assert.equal(num(cohorts,'D20'),'');
sales.getRange('B5').values=[['Germany']];
close(num(sales,'D12'),cm.find(x=>x.country==='Germany'&&x.month==='2011-01').net_pence/100);
const germany=cm.filter(x=>x.country==='Germany').reduce((a,b)=>a+b.net_pence,0)/100;
close(num(sales,'D24'),germany);
sales.getRange('B5').values=[['Все страны']];
wb.recalculate();
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!',options:{useRegex:true,maxResults:20},maxChars:2000});
await fs.writeFile(path.join(out,'formula_check.json'),errors.ndjson);
console.log(errors.ndjson);
const inspection=await wb.inspect({kind:'table',range:'Продажи!A24:G24',include:'values,formulas',tableMaxRows:2,tableMaxCols:7,maxChars:1600});console.log(inspection.ndjson);
for(const [sheet,range,name] of [[sales,'A1:P26','sales'],[cohorts,'A1:Q25','cohorts'],[source,'A1:F20','source']]){
  const preview=await wb.render({sheetName:sheet.name,range,scale:1.3,format:'png'});
  await fs.writeFile(path.join(out,`${name}-preview.png`),new Uint8Array(await preview.arrayBuffer()));
}
await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(out,'Retail_Analytics.xlsx'));
await fs.writeFile(path.join(out,'verification.json'),JSON.stringify({net_gbp:num(sales,'D24'),orders:num(sales,'E24'),weighted_m1:num(cohorts,'D5'),germany_net:germany,november_m1:num(cohorts,'D20')},null,2));
console.log('Workbook exported and calculations checked.');
