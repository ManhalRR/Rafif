"""Validate PBIR against Microsoft JSON schemas and independent data controls.
This validates definitions and source data, not Power BI Desktop rendering/DAX.
"""
from pathlib import Path
import csv, json, sqlite3, urllib.request, urllib.parse, warnings
import jsonschema
from referencing import Registry, Resource
ROOT=Path(__file__).resolve().parent
CACHE=ROOT.parent/'tmp/pbi_schema_cache';CACHE.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name,ok):
    if not ok:raise AssertionError(name)
    checks.append({'check':name,'passed':True})
def retrieve(uri):
    path=urllib.parse.urlparse(uri).path
    if path.startswith('/json-schemas/'):
        path=path[len('/json-schemas/'):]
    else:raise ValueError('Unexpected schema origin '+uri)
    local=CACHE/path
    if not local.exists():
        url='https://raw.githubusercontent.com/microsoft/json-schemas/main/'+path
        req=urllib.request.Request(url,headers={'User-Agent':'Rafif-Portfolio-Validation'})
        with urllib.request.urlopen(req,timeout=30) as r: data=r.read()
        local.parent.mkdir(parents=True,exist_ok=True);local.write_bytes(data)
    content=json.loads(local.read_text(encoding='utf-8'))
    return Resource.from_contents(content)
registry=Registry(retrieve=retrieve)
for f in (ROOT/'powerbi/Retail.Report').rglob('*.json'):
    data=json.loads(f.read_text(encoding='utf-8'))
    uri=data['$schema'];schema=retrieve(uri).contents
    validator=jsonschema.Draft7Validator(schema,registry=registry)
    errors=list(validator.iter_errors(data))
    if errors:
        print(f)
        for e in errors[:5]:print(list(e.path),e.message)
        raise AssertionError('Schema errors')
    check('Microsoft schema: '+str(f.relative_to(ROOT/'powerbi')),True)
f=ROOT/'powerbi/Retail.Report/definition.pbir'
d=json.loads(f.read_text(encoding='utf-8'));jsonschema.Draft7Validator(retrieve(d['$schema']).contents,registry=registry).validate(d)
check('Report points to included semantic model',(f.parent/d['datasetReference']['byPath']['path']/'model.bim').exists())
model=json.loads((ROOT/'powerbi/Retail.SemanticModel/model.bim').read_text(encoding='utf-8'))
tables={t['name']:t for t in model['model']['tables']}
for r in model['model']['relationships']:
    for side in ['from','to']:
        check('Relationship '+r[side+'Table']+'.'+r[side+'Column'],r[side+'Column'] in [c['name'] for c in tables[r[side+'Table']]['columns']])
with (ROOT/'results/retail_country_month.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
check('Net sales integer pence',sum(int(r['net_pence']) for r in rows)==858724702)
check('Order total',sum(int(r['orders']) for r in rows)==17582)
db=ROOT/'data/portfolio.sqlite'
if db.exists():
    with sqlite3.connect(db) as conn:
        cross=conn.execute("SELECT COUNT(*) FROM (SELECT invoice_no FROM transactions WHERE quantity>0 AND invoice_date>='2011-01-01' AND invoice_date<'2011-12-01' GROUP BY invoice_no HAVING COUNT(DISTINCT country || '|' || substr(invoice_date,1,7))>1)").fetchone()[0]
    check('Invoices do not cross country-month grains',cross==0)
de=[r for r in rows if r['country']=='Germany']
check('Germany filter',sum(int(r['net_pence']) for r in de)==19933067 and sum(int(r['orders']) for r in de)==410)
q1=[r for r in de if r['month']<='2011-03']
check('Country and month filters',sum(int(r['net_pence']) for r in q1)==3959069 and sum(int(r['orders']) for r in q1)==82)
with (ROOT/'results/retail_cohorts.csv').open(encoding='utf-8') as f:co=list(csv.DictReader(f))
m1=[r for r in co if r['age']=='1' and '2011-01'<=r['cohort']<='2011-10']
ratio=sum(float(r['active_customers']) for r in m1)/sum(int(r['cohort_size']) for r in m1)
check('Weighted M1',abs(ratio-.19941728714794432)<1e-12)
check('Unobserved window remains empty',next(r for r in co if r['cohort']=='2011-11' and r['age']=='1')['active_customers']=='')
result={'checks':checks,'checks_passed':len(checks),'power_bi_desktop_tested':False,'dax_engine_tested':False,'scope':'Microsoft JSON schemas, references and independent source-data controls. Visual rendering and DAX evaluation require Power BI Desktop.'}
(ROOT/'powerbi/validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks_passed':len(checks),'power_bi_desktop_tested':False}))
