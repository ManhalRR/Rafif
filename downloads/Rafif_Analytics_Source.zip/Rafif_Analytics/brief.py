"""Create the project overview from verified analytical outputs."""
from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
import pypdfium2 as pdfium

ROOT = Path(__file__).resolve().parent
D = json.loads((ROOT/'results/dashboard_data.json').read_text(encoding='utf-8'))
T, Q, A = D['retail']['totals'], D['retail']['quality'], D['ab']
pdfmetrics.registerFont(TTFont('Arial', 'C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('ArialBold', 'C:/Windows/Fonts/arialbd.ttf'))
OUT = ROOT/'reports/Rafif_Project_Overview.pdf'
C = canvas.Canvas(str(OUT), pagesize=(1000,720))
C.setTitle('Рафиф Алшауи - аналитические кейсы')
C.setAuthor('')
INK, MUTED, TEAL = '#14243A', '#5B6C80', '#087F8C'

def text(x,y,s,size=12,color=INK,bold=False):
    C.setFont('ArialBold' if bold else 'Arial',size)
    C.setFillColor(HexColor(color))
    C.drawString(x,720-y-size,s)

def paragraph(x,y,s,w,size=12,maxh=90,color=INK):
    p=Paragraph(s,ParagraphStyle('p',fontName='Arial',fontSize=size,leading=size*1.4,textColor=HexColor(color)))
    _,h=p.wrap(w,maxh)
    assert h<=maxh,(s,h,maxh)
    p.drawOn(C,x,720-y-h)

def block(y,number,title,source,task,method,result,metric,metric_label,decision):
    C.setFillColor(HexColor('#FFFFFF'))
    C.roundRect(40,720-y-242,920,242,14,stroke=0,fill=1)
    text(60,y+17,number,12,TEAL,True)
    text(98,y+12,title,21,bold=True)
    text(98,y+43,source,10,MUTED)
    for yy,label,body in [(y+74,'ЗАДАЧА',task),(y+116,'МЕТОД',method),(y+176,'РЕЗУЛЬТАТ',result)]:
        text(60,yy,label,9,TEAL,True)
        paragraph(151,yy-2,body,468,11.5,maxh=59)
    C.setFillColor(HexColor('#EAF3F5'))
    C.roundRect(651,720-y-222,287,153,11,stroke=0,fill=1)
    text(669,y+82,metric,29,bold=True)
    paragraph(669,y+123,metric_label,245,10.5,maxh=32,color=MUTED)
    paragraph(669,y+164,decision,245,11,maxh=48)

C.setFillColor(HexColor('#F3F6FA'));C.rect(0,0,1000,720,stroke=0,fill=1)
text(40,25,'РАФИФ АЛШАУИ / DATA ANALYST',11,bold=True)
text(735,25,'SQL  ·  PYTHON  ·  АНАЛИТИКА',10,TEAL,True)
text(40,61,'Аналитика для бизнес-решений',31,bold=True)
text(40,108,'Два прикладных кейса: задача, метод, результат и проверяемый вывод',12,MUTED)
num=lambda v:f'{v:,.0f}'.replace(',',' ')
percent=lambda v:f'{v*100:.1f}%'.replace('.',',')
delta=f"+{A['delta']*100:.2f}".replace('.',',')+' п.п.'
ci='-'.join(f'{x*100:.2f}'.replace('.',',') for x in A['difference_ci95_newcombe'])
block(146,'01','Продажи и удержание клиентов',
      'Открытые данные UCI Online Retail · январь-ноябрь 2011',
      'Оценить динамику продаж, отмены и повторные покупки; определить направления дополнительного анализа.',
      f"Обработаны {num(Q['source_rows'])} строк. SQL: CTE, JOIN, оконные функции; Python/pandas. Когорты M0-M5, сверка денежных итогов и качества данных.",
      'Интерактивный дашборд по странам и месяцам, когортная таблица, SQL-запросы и воспроизводимый расчёт.',
      percent(T['m1_weighted_retention']),
      'Повторная покупка в M1; взвешенно по когортам января-октября',
      'Следующий шаг: изучить причины отмен и различия между когортами.')
block(406,'02','Оценка эффекта A/B-эксперимента',
      'Синтетические данные · 24 000 участников · конверсия за 7 дней',
      'Проверить различие конверсии между вариантами A и B и оценить неопределённость эффекта.',
      'Фиксированный горизонт, ITT-анализ, проверка SRM; тест разницы долей и 95% интервал Newcombe/Wilson.',
      'Статистический отчёт с диагностикой групп, оценкой эффекта и условиями интерпретации; код и данные.',
      delta,
      f'Разница конверсии B - A; 95% ДИ: {ci} п.п.',
      'В заданной модели B улучшает конверсию. Вывод о росте выручки не подтверждён.')
text(40,672,'Данные, SQL, Python, методика и проверки включены в комплект. Имена работодателей и внутренние данные не используются.',9,MUTED)
text(40,690,'Источник кейса 01: Chen, D. (2015), UCI Online Retail, DOI 10.24432/C5BW33, CC BY 4.0. Анализ и визуализация.',8,MUTED)
C.save()
doc=pdfium.PdfDocument(str(OUT))
doc[0].render(scale=1.5).to_pil().save(ROOT/'reports/project-overview.png')
print('Created project overview.')
