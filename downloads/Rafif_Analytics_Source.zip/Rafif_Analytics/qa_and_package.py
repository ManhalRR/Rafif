"""Run SQL/PDF checks and package deliverables; never manufacture a browser test.

Optional manual browser evidence may be supplied in results/manual_ui_validation.json:
{
  "performed_at_utc": "<actual ISO-8601 time with UTC offset>",
  "artifact_sha256": {"index.html": "<sha256>", "results/dashboard_data.json": "<sha256>"},
  "observations": {"Germany_Jan_March": "<actual observation>", ...}
}
Only a real browser review should create that separate record. This script keeps
it historical, checks artifact hashes and never changes its observation date.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3
import zipfile

from pypdf import PdfReader
import pypdfium2 as pdfium

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manual_evidence(root):
    """Reference prior human/browser evidence without claiming a new UI test."""
    evidence_path = root / 'results/manual_ui_validation.json'
    if not evidence_path.is_file():
        return {'status': 'not_performed', 'executed_in_this_run': False,
                'reason': 'No separate dated manual browser-validation record was supplied.'}
    try:
        evidence = json.loads(evidence_path.read_text(encoding='utf-8'))
        if not isinstance(evidence, dict) or not isinstance(evidence.get('performed_at_utc'), str):
            raise ValueError('A record with performed_at_utc text is required')
        performed = datetime.fromisoformat(evidence['performed_at_utc'].replace('Z', '+00:00'))
        if performed.tzinfo is None or performed > datetime.now(timezone.utc):
            raise ValueError('Observation time must be timezone-aware and not in the future')
        if not isinstance(evidence.get('observations'), dict) or not evidence['observations']:
            raise ValueError('Actual observations are required')
        mismatches = [name for name in ('index.html', 'results/dashboard_data.json')
                      if evidence.get('artifact_sha256', {}).get(name) != digest(root / name)]
    except (KeyError, ValueError, TypeError, OSError) as error:
        return {'status': 'invalid_record', 'executed_in_this_run': False,
                'source': str(evidence_path.relative_to(root)), 'reason': str(error)}
    return {'status': 'historical_record_matches_artifacts' if not mismatches else 'historical_record_is_stale',
            'executed_in_this_run': False, 'source': str(evidence_path.relative_to(root)),
            'record_sha256': digest(evidence_path), 'performed_at_utc': evidence['performed_at_utc'],
            'artifact_mismatches': mismatches, 'observations': evidence['observations']}


def main():
    with sqlite3.connect((ROOT / 'data/portfolio.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        row = db.execute('''SELECT SUM(amount_pence)/100.0,
        COUNT(DISTINCT CASE WHEN quantity>0 THEN invoice_no END),
        -SUM(CASE WHEN quantity<0 THEN amount_pence ELSE 0 END)*1.0/
        SUM(CASE WHEN quantity>0 THEN amount_pence ELSE 0 END)
        FROM transactions WHERE country='Germany' AND invoice_date>='2011-01-01'
        AND invoice_date<'2011-04-01' ''').fetchone()
    assert round(row[0]) == 39591 and row[1] == 82 and round(row[2] * 100, 1) == 3.2
    pdf_path = ROOT / 'reports/Rafif_Analytics_Portfolio.pdf'
    reader = PdfReader(pdf_path)
    assert len(reader.pages) == 3
    pdftext = '\n'.join(page.extract_text() for page in reader.pages)
    for forbidden in ['ПОДГОТОВЛЕНО ИИ', 'ИИ-ассистентом', 'ICS Consulting', 'ForMagicLife']:
        assert forbidden not in pdftext
    assert 'СИНТЕТИЧЕСКИЕ ДАННЫЕ' in pdftext and 'CC BY 4.0' in pdftext
    doc = pdfium.PdfDocument(str(pdf_path))
    try:
        for i, page in enumerate(doc):
            page.render(scale=1.6).to_pil().save(str(ROOT / 'reports' / f'project-{i+1}.png'))
    finally:
        doc.close()
    checks = {
        'automated_checks': {
            'performed_at_utc': datetime.now(timezone.utc).isoformat(),
            'Germany_Jan_March_SQL': {'net_gbp': row[0], 'orders': row[1], 'cancellation_ratio': row[2]},
            'pdf_pages': len(reader.pages), 'pdf_text_checks': 'passed', 'pdf_rasterization': 'completed',
            'artifact_sha256': {'data/portfolio.sqlite': digest(ROOT / 'data/portfolio.sqlite'),
                               'reports/Rafif_Analytics_Portfolio.pdf': digest(pdf_path)},
        },
        'manual_ui_validation': manual_evidence(ROOT),
    }
    (ROOT / 'results/ui_validation.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    output = ROOT.parent / 'output/Rafif_Analytics_Portfolio.zip'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for file in sorted(ROOT.rglob('*')):
            if (file.is_file() and file.suffix not in ['.sqlite', '.pyc', '.ndjson']
                    and file.name != 'online_retail.zip' and not file.name.startswith('~$')
                    and not file.name.endswith('-preview.png') and '__pycache__' not in file.parts):
                archive.write(file, 'Rafif_Analytics_Portfolio/' + file.relative_to(ROOT).as_posix())
    print(json.dumps({'validation': checks, 'zip_bytes': output.stat().st_size,
                      'zip_sha256': digest(output)}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
