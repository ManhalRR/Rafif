"""Render the demonstration portfolio from computed outputs; never hand-type metrics."""
from pathlib import Path
import json, math, html
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle

ROOT=Path(__file__).resolve().parent
R=ROOT/'reports';R.mkdir(exist_ok=True)
D=json.loads((ROOT/'results'/'dashboard_data.json').read_text(encoding='utf-8'))
T=D['retail']['totals']; Q=D['retail']['quality']; A=D['ab']
pdfmetrics.registerFont(TTFont('Arial','C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('ArialBold','C:/Windows/Fonts/arialbd.ttf'))
NAVY='#14243A'; TEAL='#087F8C'; BLUE='#4B71D9'; GRAY='#5B6C80'; BG='#F3F6FA'; RED='#BC4B52'
W,H=900,630
C=canvas.Canvas(str(R/'Rafif_Analytics_Portfolio.pdf'),pagesize=(W,H))
C.setTitle('Рафиф Алшауи - портфолио аналитика данных')
C.setAuthor('')

def n(v):return f'{v:,.0f}'.replace(',',' ')
def pct(v,d=1):return f'{v*100:.{d}f}%'.replace('.',',')
def pp(v):return f'{v*100:+.2f}'.replace('.',',')+' п.п.'
def gbp(v):return '£'+n(v)
def rect(x,t,w,h,fill='#FFFFFF',radius=12):
    C.setFillColor(HexColor(fill));C.roundRect(x,H-t-h,w,h,radius,fill=1,stroke=0)
def txt(x,t,s,size=12,color=NAVY,bold=False):
    C.setFillColor(HexColor(color));C.setFont('ArialBold' if bold else 'Arial',size);C.drawString(x,H-t-size,str(s))
def para(x,t,s,w,size=11,color=GRAY,maxh=100):
    style=ParagraphStyle('p',fontName='Arial',fontSize=size,leading=size*1.42,textColor=HexColor(color))
    p=Paragraph(s,style);pw,ph=p.wrap(w,maxh)
    if ph>maxh:raise ValueError(f'Overflow {ph}>{maxh}: {s[:60]}')
    p.drawOn(C,x,H-t-ph)
    return ph
def header(k,title,subtitle):
    C.setFillColor(HexColor(BG));C.rect(0,0,W,H,fill=1,stroke=0)
    txt(42,25,'РАФИФ АЛШАУИ / DATA ANALYTICS',11,bold=True)
    txt(604,25,'SQL / PYTHON / АНАЛИТИКА',10,TEAL,True)
    txt(42,64,title,27,bold=True);txt(42,106,subtitle,11,GRAY)
    C.setStrokeColor(HexColor('#DCE4ED'));C.line(42,46,858,46)
    footer=('Источник: Chen, D. (2015), UCI Online Retail, DOI 10.24432/C5BW33, CC BY 4.0. Открытые данные; очистка и агрегация.'
            if k<=2 else 'Модель эксперимента на синтетических данных. Воспроизводимый расчёт, код и методика приложены.')
    txt(42,594,footer,8 if k<=2 else 9,GRAY)
    txt(818,594,f'{k} / 3',9,GRAY)
def kpi(x,label,value,sub,w=256):
    rect(x,144,w,87);txt(x+16,157,label,10,GRAY);txt(x+16,177,value,25,bold=True)
    subsize=min(9,9*(w-32)/max(1,pdfmetrics.stringWidth(sub,'Arial',9)))
    txt(x+16,211,sub,subsize,GRAY)
def bullets(x,t,items,w,size=11,maxh=48,gap=12):
    for s in items:
        h=para(x,t,s,w,size,maxh=maxh);t+=h+gap
def bars(x,t,w,h,labels,values):
    lo=min([0]+values);hi=max([0]+values)*1.18;span=hi-lo or 1
    chart_h=h-38; yy=lambda v:H-t-chart_h+(v-lo)/span*chart_h
    zero=yy(0);step=w/len(values)
    C.setStrokeColor(HexColor('#D6E0EB'));C.line(x,zero,x+w,zero)
    for i,(label,v) in enumerate(zip(labels,values)):
        C.setFillColor(HexColor(TEAL if v>=0 else RED))
        C.roundRect(x+i*step+7,min(zero,yy(v)),step-14,max(1,abs(yy(v)-zero)),3,fill=1,stroke=0)
        txt(x+i*step+4,t+h-26,label,9,GRAY)
    txt(x,t-16,'£, тыс.  |  максимум '+n(max(values)/1000),9,GRAY)

header(1,'Продажи: от строк к решениям','Проект 01 · UCI Online Retail · январь-ноябрь 2011 · Python / SQL / контроль качества')
kpi(42,'Оборот после отмен',gbp(T['net_gbp']),'Сумма строк продаж минус строки отмен')
kpi(322,'Заказы с продажами',n(T['orders']),'Уникальные InvoiceNo, положительные продажи')
kpi(602,'Сумма отмен / продажи',pct(T['cancellation_value_ratio']),'Стоимостное отношение; не доля возвращённых заказов')
rect(42,249,507,251);txt(60,265,'Оборот по полным месяцам',14,bold=True)
bars(65,310,461,174,[r['month'][5:] for r in D['retail']['monthly']],[r['net_pence']/100 for r in D['retail']['monthly']])
rect(569,249,289,251);txt(587,265,'Что видно в данных',14,bold=True)
bullets(587,301,[f"Пиковый месяц: <b>{T['peak_month']}</b>, оборот после отмен {gbp(T['peak_net_gbp'])}.",
 f"На Великобританию приходится <b>{pct(T['uk_net_share'])}</b> оборота после отмен.",
 'Декабрь 2011 исключён: в источнике он неполный. Сравнение с полным ноябрём исказило бы тренд.'],253,10.5,63,12)
rect(42,516,816,62,'#E1EFF1');para(58,526,'<b>Решение для обсуждения:</b> проверить причины отмен и структуру крупных заказов; для выводов о повторяющейся сезонности нужны дополнительные годы. Эти данные не доказывают влияние маркетинга и не содержат расходов для расчёта ROI.',783,10.5,maxh=49)
C.showPage()

header(2,'Когорты и качество данных','Проект 01 · первая наблюдаемая покупка · пропуски, дубли и цензура наблюдения')
kpi(42,'Возврат к покупке в M1',pct(T['m1_weighted_retention']),'Взвешенно по когортам января-октября 2011')
kpi(322,'Нет CustomerID в источнике',pct(Q['missing_customer_id_share_source']),'Выручка учитывается; когорты - только известные ID')
kpi(602,'Повторяющиеся строки',n(Q['exact_duplicate_rows']),'Сохранены: нет надёжного идентификатора строки')
rect(42,249,496,279);txt(60,263,'Повторная покупка по когортам',14,bold=True)
cohorts=sorted(set(r['cohort'] for r in D['retail']['cohorts']))
lookup={(r['cohort'],r['age']):r['retention'] for r in D['retail']['cohorts']}
for j in range(6):txt(180+j*55,292,'M'+str(j),9,GRAY,True)
for i,cohort in enumerate(cohorts):
    top=311+i*16;txt(60,top,cohort,9,GRAY)
    for j in range(6):
        v=lookup[(cohort,j)]; xx=171+j*55
        color='#E8EDF3' if v is None else Color(.90-.75*v,.96-.47*v,.97-.42*v)
        C.setFillColor(HexColor(color) if isinstance(color,str) else color);C.rect(xx,H-top-14,51,14,fill=1,stroke=0)
        txt(xx+7,top+1,'—' if v is None else pct(v,0),8,'#FFFFFF' if v is not None and v>.55 else NAVY)
rect(557,249,301,279);txt(575,263,'Правила, которые важны',14,bold=True)
bullets(575,296,[
 'Первая покупка - первая <b>наблюдаемая</b> в данных, а не доказанная дата привлечения клиента.',
 'Недоступные будущие месяцы показаны прочерком. Они не превращены в нулевое удержание.',
 f"После удаления точных дублей оборот изменился бы на {gbp(Q['duplicate_sensitivity_net_gbp'])}. Это анализ чувствительности, а не основание удалить строки.",
 'SQL проверен независимыми расчётами pandas: суммы, размеры когорт и повторные покупки.'
],265,10,55,10)
para(48,542,'Источник: Chen, D. (2015). Online Retail. UCI Machine Learning Repository. DOI: 10.24432/C5BW33. CC BY 4.0. Анализ и визуализации являются преобразованием исходных данных.',804,9.5,maxh=36)
C.showPage()

header(3,'A/B-тест: эффект и неопределённость','Проект 02 · СИНТЕТИЧЕСКИЕ ДАННЫЕ · 24 000 участников · фиксированный горизонт')
aa,bb=A['groups'];ci=A['difference_ci95_newcombe']
kpi(42,'Изменение конверсии B − A',pp(A['delta']),'Основная метрика: конверсия за 7 дней')
kpi(322,'95% доверительный интервал',f"{ci[0]*100:.2f}…{ci[1]*100:.2f} п.п.",'Newcombe / Wilson, разница долей')
kpi(602,'Двустороннее p-value',f"{A['p_value_two_sided']:.4f}",'Порог 0,05 задан до расчёта')
rect(42,249,400,240);txt(60,265,'Конверсия по группам',14,bold=True)
for i,g in enumerate([aa,bb]):
    top=310+i*72;txt(62,top,'Группа '+g['variant'],12,bold=True)
    rect(153,top,246,24,'#E8EDF3',4);rect(153,top,246*g['conversion_rate']/.18,24,TEAL if i else BLUE,4)
    txt(162,top+3,pct(g['conversion_rate'],2),12,'#FFFFFF',True)
    txt(154,top+31,f"{n(g['conversions'])} / {n(g['users'])} участников",10,GRAY)
rect(461,249,397,240);txt(479,265,'Решение в рамках симуляции',14,bold=True)
decision='Конверсия B выше A, интервал не включает ноль.' if ci[0]>0 else 'Убедительного роста конверсии не обнаружено.'
bullets(479,300,[f'<b>{decision}</b>',
 f"Проверка SRM: p = {A['srm_p_value']:.3f}; при пороге 0,01 значимого перекоса групп не обнаружено.",
 'Знаменатель - все назначенные участники. У каждого завершилось 7-дневное окно наблюдения.',
 'Это результат сгенерированного эксперимента, не рост показателей реальной компании.'
],359,10.5,48,10)
rect(42,505,816,74,'#E1EFF1');para(58,516,
 '<b>Ограничения и проверка:</b> генератор, seed и SQL включены в комплект. Один основной тест, без повторного просмотра p-value и без выбора удачного seed. Выручка на участника - дополнительная исследовательская метрика. Реальное внедрение потребовало бы проверки бизнес-ограничений и качества эксперимента.',783,10.5,maxh=58)
C.showPage();C.save()

template=r'''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Рафиф Алшауи · аналитическое портфолио</title>
<style>
:root{--ink:#14243a;--muted:#5b6c80;--teal:#087f8c;--bg:#f3f6fa}*{box-sizing:border-box}body{font:15px/1.5 system-ui,Segoe UI,sans-serif;background:var(--bg);color:var(--ink);margin:0}main{max-width:1180px;margin:auto;padding:32px 28px}header{display:flex;justify-content:space-between;gap:20px;align-items:center}h1{font-size:clamp(26px,4vw,42px);margin:20px 0 6px;letter-spacing:-1px}h2{margin:0 0 18px;font-size:20px}h3{font-size:16px;margin:0 0 10px}p{margin:8px 0}.eyebrow{font-weight:750;font-size:12px;letter-spacing:1.6px}.badge{color:var(--teal);background:#dceff0;padding:8px 12px;border-radius:20px;font-size:12px;font-weight:700}.muted{color:var(--muted)}nav{display:flex;gap:10px;margin:24px 0}button,select{font:inherit;border:1px solid #cbd7e5;background:white;color:var(--ink);padding:10px 14px;border-radius:9px;cursor:pointer}button[aria-pressed=true]{background:var(--ink);color:white}button:focus-visible,select:focus-visible,a:focus-visible{outline:3px solid #eab84c;outline-offset:3px}.filters{display:flex;gap:12px;flex-wrap:wrap;align-items:end;margin-bottom:20px}.filters label{display:grid;gap:5px;font-size:12px;color:var(--muted)}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.card,.panel{background:white;border:1px solid #e2e9f1;border-radius:16px;padding:22px}.number{font-size:clamp(24px,3vw,34px);font-weight:750;letter-spacing:-.7px}.label{font-size:12px;color:var(--muted);margin-bottom:5px}.small{font-size:12px;color:var(--muted)}.two{display:grid;grid-template-columns:1.35fr 1fr;gap:18px;margin-top:18px}.panel{margin-top:18px}.two .panel{margin-top:0}svg{width:100%;height:auto;display:block}table{width:100%;border-collapse:separate;border-spacing:4px;font-size:12px}th{text-align:left;padding:5px;color:var(--muted)}td{padding:7px;text-align:center;border-radius:5px}.note{border-left:4px solid var(--teal);padding:12px 18px;background:#e5f1f2;margin-top:18px}.list{padding-left:20px}.list li{margin:10px 0}footer{margin-top:28px;padding:20px 0;border-top:1px solid #d9e2ec;font-size:12px;color:var(--muted)}a{color:var(--teal)}[hidden]{display:none!important}.bar{display:flex;gap:16px;align-items:center;margin:25px 0}.track{height:32px;background:#e8edf3;border-radius:7px;flex:1}.fill{height:32px;background:var(--teal);border-radius:7px;color:white;padding:4px 12px;font-weight:700;min-width:74px}.error{color:#ad2d39;font-weight:650}.scroll{overflow-x:auto}@media(max-width:720px){main{padding:22px 16px}header{align-items:start;flex-direction:column;gap:10px}.grid,.two{grid-template-columns:1fr}.number{font-size:32px}.filters select{max-width:100%}.filters label{width:100%}}
</style><main><header><div class="eyebrow">РАФИФ АЛШАУИ / DATA ANALYTICS</div><span class="badge">SQL / PYTHON / АНАЛИТИКА</span></header>
<h1>Аналитика для бизнес-решений</h1><p class="muted">Два воспроизводимых проекта: продажи и когортный анализ на открытых данных; A/B-тест на синтетических данных.</p>
<p class="small"><a href="reports/Rafif_Project_Overview.pdf">Обзор кейсов · PDF</a> &nbsp; / &nbsp; <a href="reports/Rafif_Analytics_Portfolio.pdf">Аналитический отчёт · PDF</a> &nbsp; / &nbsp; <a href="README.txt">Данные и методика</a> &nbsp; / &nbsp; <a href="analyze.py">Python-код</a> &nbsp; / &nbsp; <a href="excel/Retail_Analytics.xlsx">Excel · формулы и диаграммы</a></p>
<nav aria-label="Проекты"><button id="retailTab" aria-pressed="true" onclick="show('retail')">01 · Продажи и когорты</button><button id="abTab" aria-pressed="false" onclick="show('ab')">02 · A/B-тест</button></nav>
<section id="retail"><div class="note" style="margin-bottom:20px"><b>Задача:</b> оценить динамику продаж, отмены и повторные покупки. <b>Результат:</b> дашборд по странам и месяцам, когортный анализ и проверка качества данных. <b>Решение для обсуждения:</b> изучить причины отмен и различия между когортами.</div><div class="filters"><label>Страна<select id="country" onchange="renderRetail()"><option value="all">Все страны</option></select></label><label>С месяца<select id="from" onchange="renderRetail()"></select></label><label>По месяц<select id="to" onchange="renderRetail()"></select></label><button onclick="resetFilters()">Сбросить фильтры</button></div><p id="filterError" class="error" role="status"></p>
<div class="grid" id="retailKpis"></div><div class="two"><div class="panel"><h2>Оборот после отмен</h2><div id="salesChart"></div><p class="small">GBP; суммы строк после очистки. Неполный декабрь 2011 исключён.</p></div><div class="panel"><h2>Что проверять бизнесу</h2><ul class="list" id="retailFindings"></ul><p class="small">Глобальные выводы по всем странам, январь-ноябрь 2011. Оборот не равен прибыли. Расходов для расчёта ROI нет.</p></div></div>
<div class="panel"><h2>Когортное удержание M0–M5</h2><p class="small">Фиксированный анализ по всем странам: фильтры выше не меняют эту таблицу. Первая наблюдаемая покупка; только известные CustomerID. Прочерк означает незавершённое окно, а не нулевое удержание.</p><div class="scroll" id="cohortTable"></div></div>
<div class="panel"><h2>Качество данных и воспроизводимость</h2><div id="quality"></div><p>В расчётах использованы CTE, JOIN, LAG, оконная накопительная сумма и когортная сетка. Денежные суммы SQL сверены с независимой агрегацией pandas; удержание - с пересечениями множеств клиентов.</p></div></section>
<section id="ab" hidden><div class="note"><b>Задача:</b> оценить различие семидневной конверсии вариантов A и B. <b>Результат:</b> статистический отчёт с проверкой групп, оценкой эффекта и доверительным интервалом. Данные: синтетическая модель, seed 20261027.</div><div class="grid" id="abKpis" style="margin-top:18px"></div><div class="two"><div class="panel"><h2>Конверсия за 7 дней</h2><div id="abBars"></div><div id="ciChart"></div></div><div class="panel"><h2>Интерпретация</h2><div id="abDecision"></div><ul class="list"><li>24 000 назначенных участников; план распределения 1:1.</li><li>Один основной двусторонний тест, α = 0,05. Анализ после полного окна наблюдения.</li><li>ITT: учитываются все назначенные участники, включая не совершивших покупку.</li><li>Вторичная метрика выручки на участника носит исследовательский характер.</li></ul></div></div><div class="panel"><h2>Условия интерпретации</h2><p>Вывод относится к заданной модели эксперимента. Перенос в продукт требует проверки трекинга, возвратов, долгосрочного удержания и заранее согласованных ограничений. Дополнительная метрика выручки не подтверждает устойчивый рост дохода.</p><p class="small">Метод: pooled z-test для нулевой разницы долей; 95% интервал разницы Newcombe на основе интервалов Wilson. SRM: χ² с одной степенью свободы, диагностический порог 0,01.</p></div></section>
<footer><p><b>SQL-запросы:</b> <a href="sql/01_monthly_sales.sql">месячные метрики</a> · <a href="sql/02_country_month.sql">страны</a> · <a href="sql/03_cohort_retention.sql">когорты</a> · <a href="sql/04_experiment.sql">эксперимент</a></p><p><b>Комплект:</b> analyze.py · sql/01…04 · data/ · results/ · README.txt · INTERVIEW_GUIDE.txt · reports/Rafif_Analytics_Portfolio.pdf</p><p>Данные проекта 01: Chen, D. (2015). <a href="https://archive.ics.uci.edu/dataset/352/online%2Bretail">Online Retail, UCI</a>, DOI 10.24432/C5BW33, <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. Выполнены очистка, агрегация и визуализация. Подготовлено 27 октября 2026.</p></footer></main>
<script>const D=__DATA__;const $=id=>document.getElementById(id);const num=n=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}).format(n);const money=n=>'£'+num(n);const pc=(n,d=1)=>(n*100).toFixed(d).replace('.',',')+'%';const pp=n=>(n>=0?'+':'')+(n*100).toFixed(2).replace('.',',')+' п.п.';
function show(id){['retail','ab'].forEach(x=>{$(x).hidden=x!==id;$(x+'Tab').setAttribute('aria-pressed',String(x===id))})}
function card(label,val,sub){return `<div class="card"><div class="label">${label}</div><div class="number">${val}</div><div class="small">${sub}</div></div>`}
const months=D.retail.monthly.map(x=>x.month);['from','to'].forEach(id=>$(id).innerHTML=months.map(m=>`<option>${m}</option>`).join(''));D.retail.countries.map(x=>x.country).sort().forEach(c=>$('country').add(new Option(c,c)));
function resetFilters(){$('from').value=months[0];$('to').value=months.at(-1);$('country').value='all';renderRetail()}
function barChart(rows){const w=600,h=260,pad=35,bottom=218;const vals=rows.map(r=>r.net_pence/100);let lo=Math.min(0,...vals),hi=Math.max(0,...vals)*1.12;if(hi===lo)hi=lo+1;const y=v=>bottom-(v-lo)/(hi-lo)*175;let z=y(0),step=530/rows.length;return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Оборот после отмен по месяцам"><line x1="35" y1="${z}" x2="575" y2="${z}" stroke="#b8c9d8"/>`+rows.map((r,i)=>{const v=vals[i],x=pad+i*step;return `<rect x="${x+6}" y="${Math.min(z,y(v))}" width="${Math.max(4,step-12)}" height="${Math.max(1,Math.abs(z-y(v)))}" rx="3" fill="${v>=0?'#087f8c':'#bc4b52'}"><title>${r.month}: ${money(v)}</title></rect><text x="${x+step/2}" y="242" text-anchor="middle" font-size="11" fill="#5b6c80">${r.month.slice(5)}</text>`}).join('')+`<text x="35" y="20" font-size="12" fill="#5b6c80">Диапазон: ${money(lo)} … ${money(hi/1.12)}</text></svg>`}
function renderRetail(){let from=$('from').value,to=$('to').value,c=$('country').value;if(from>to){$('filterError').textContent='Начальный месяц должен быть не позднее конечного.';$('retailKpis').innerHTML='';$('salesChart').innerHTML='';return}$('filterError').textContent='';let rows=D.retail.country_month.filter(r=>r.month>=from&&r.month<=to&&(c==='all'||r.country===c));let series=months.filter(m=>m>=from&&m<=to).map(m=>{let sub=rows.filter(r=>r.month===m);return {month:m,net_pence:sub.reduce((a,r)=>a+r.net_pence,0)}});const sum=k=>rows.reduce((s,r)=>s+r[k],0),gross=sum('gross_pence');$('retailKpis').innerHTML=card('Оборот после отмен',money(sum('net_pence')/100),`${from} … ${to} · ${c==='all'?'все страны':c}`)+card('Заказы с продажами',num(sum('orders')),'Уникальные счета с положительными продажами')+card('Сумма отмен / продажи',gross?pc(sum('cancellations_pence')/gross):'—','Стоимостное отношение; не частота возвратов');$('salesChart').innerHTML=barChart(series)}
const t=D.retail.totals,q=D.retail.quality;$('retailFindings').innerHTML=`<li>Пиковый месяц: <b>${t.peak_month}</b>, ${money(t.peak_net_gbp)} после отмен.</li><li>Доля Великобритании: <b>${pc(t.uk_net_share)}</b> оборота после отмен.</li><li>Проверить причины отмен и структуру крупных заказов. По одному году нельзя подтвердить повторяющуюся сезонность.</li>`;
let cohorts=[...new Set(D.retail.cohorts.map(r=>r.cohort))];$('cohortTable').innerHTML='<table><thead><tr><th>Когорта</th>'+Array.from({length:6},(_,i)=>`<th>M${i}</th>`).join('')+'</tr></thead><tbody>'+cohorts.map(c=>'<tr><th>'+c+'</th>'+D.retail.cohorts.filter(r=>r.cohort===c).map(r=>{let v=r.retention;return `<td title="База когорты: ${r.cohort_size}; активны: ${r.active_customers??'окно не завершено'}" style="background:${v===null?'#e8edf3':`rgba(8,127,140,${.10+.80*v})`};color:${v!==null&&v>.5?'white':'#14243a'}">${v===null?'—':pc(v,0)}</td>`}).join('')+'</tr>').join('')+'</tbody></table>';
$('quality').innerHTML=`<ul class="list"><li>Исходных строк: <b>${num(q.source_rows)}</b>; принято после правил очистки: ${num(q.accepted_rows_all_dates)}; в отчётном периоде: ${num(q.reporting_rows)}.</li><li>Пропущен CustomerID в ${pc(q.missing_customer_id_share_source)} исходных строк. Неизвестные клиенты остаются в денежных метриках.</li><li>${num(q.exact_duplicate_rows)} точных повторов сохранены. Удаление изменило бы оборот периода на ${money(q.duplicate_sensitivity_net_gbp)}; это анализ чувствительности.</li><li>Из расчётов исключены неположительные цены, неподходящие знаки количества и некорректные даты. Декабрь 2010 используется только для истории первых наблюдаемых покупок.</li></ul>`;
const a=D.ab,ci=a.difference_ci95_newcombe;$('abKpis').innerHTML=card('Разница конверсий B − A',pp(a.delta),'Синтетические данные')+card('95% интервал разницы',`${(ci[0]*100).toFixed(2)} … ${(ci[1]*100).toFixed(2)}`,'Процентные пункты, Newcombe / Wilson')+card('Двустороннее p-value',a.p_value_two_sided.toFixed(4),'Основной тест, α = 0,05');
$('abBars').innerHTML=a.groups.map(g=>`<div class="bar"><b>${g.variant}</b><div style="flex:1"><div class="track"><div class="fill" style="width:${g.conversion_rate/.18*100}%">${pc(g.conversion_rate,2)}</div></div><div class="small">${num(g.conversions)} / ${num(g.users)} участников</div></div></div>`).join('');
let min=Math.min(0,ci[0])-.004,max=ci[1]+.004,xx=v=>45+(v-min)/(max-min)*500;$('ciChart').innerHTML=`<svg viewBox="0 0 590 105" role="img" aria-label="Доверительный интервал эффекта"><line x1="${xx(0)}" y1="15" x2="${xx(0)}" y2="70" stroke="#879ab0" stroke-dasharray="4"/><line x1="${xx(ci[0])}" y1="42" x2="${xx(ci[1])}" y2="42" stroke="#087f8c" stroke-width="5"/><circle cx="${xx(a.delta)}" cy="42" r="7" fill="#14243a"/><text x="${xx(0)}" y="95" text-anchor="middle" font-size="12">0</text><text x="${xx(a.delta)}" y="22" text-anchor="middle" font-size="12">${pp(a.delta)}</text><text x="${xx(ci[0])}" y="67" text-anchor="middle" font-size="11">${(ci[0]*100).toFixed(2)}</text><text x="${xx(ci[1])}" y="67" text-anchor="middle" font-size="11">${(ci[1]*100).toFixed(2)} п.п.</text></svg>`;
$('abDecision').innerHTML=`<p><b>${ci[0]>0?'В симуляции конверсия B выше A; интервал не включает ноль.':'Убедительного роста конверсии в симуляции не обнаружено.'}</b></p><p>SRM: p = ${a.srm_p_value.toFixed(3)}. При пороге 0,01 ${a.srm_p_value>=.01?'значимый перекос групп не обнаружен':'обнаружен значимый перекос групп'}.</p><p class="small">Изменение выручки на участника: ${num(a.rpu_delta_rub)} ₽; 95% нормальный интервал [${num(a.rpu_ci95_normal[0])}; ${num(a.rpu_ci95_normal[1])}] ₽. Дополнительная метрика, без самостоятельного вывода о запуске.</p>`;resetFilters();
</script></html>'''
(ROOT/'index.html').write_text(template.replace('__DATA__',json.dumps(D,ensure_ascii=False).replace('</',r'<\/')),encoding='utf-8')
print('Created:',R/'Rafif_Analytics_Portfolio.pdf',ROOT/'index.html')
